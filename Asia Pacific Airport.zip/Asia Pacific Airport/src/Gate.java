
public class Gate {
    private int number;

    public Gate(int number) {
        this.number = number;
    }

    public int getName() {
        return number;
    }
}
